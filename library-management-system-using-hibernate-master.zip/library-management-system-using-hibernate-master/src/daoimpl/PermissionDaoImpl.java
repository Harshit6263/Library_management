package daoimpl;

public class PermissionDaoImpl {

}
